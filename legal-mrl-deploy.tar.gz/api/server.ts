import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import multer from 'multer'
import { v4 as uuidv4 } from 'uuid'
import { createClient } from '@sanity/client'

const app = express()
const upload = multer({ dest: 'uploads/' })

app.use(cors())
app.use(express.json())

// Подключение к БД (drizzle)
import { drizzle } from 'drizzle-orm/mysql2'
import mysql from 'mysql2/promise'
import { cases, documents } from '../db/schema'
import { eq } from 'drizzle-orm'

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'legal_mrl',
  password: process.env.DB_PASSWORD || '@t+G7s8wWNzV',
  database: process.env.DB_NAME || 'legal_mrl'
})

const db = drizzle(pool)

// OpenAI
import OpenAI from 'openai'
const openai = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY || 'your-key-here',
  baseURL: 'https://openrouter.ai/api/v1'
})

// Роуты API

// Создание дела
app.post('/api/cases', upload.array('files'), async (req, res) => {
  try {
    const { title, description } = req.body
    const caseId = uuidv4()
    
    await db.insert(cases).values({
      id: caseId,
      title,
      description: description || null,
      status: 'pending'
    })

    // Сохраняем файлы
    const files = req.files as Express.Multer.File[]
    if (files?.length) {
      for (const file of files) {
        const docId = uuidv4()
        await db.insert(documents).values({
          id: docId,
          caseId,
          name: file.originalname,
          type: file.mimetype,
          size: file.size,
          path: file.path
        })
      }
    }

    res.json({ id: caseId, success: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to create case' })
  }
})

// Список дел
app.get('/api/cases', async (req, res) => {
  try {
    const allCases = await db.select().from(cases)
    
    // Добавляем количество документов
    const result = await Promise.all(
      allCases.map(async (c) => {
        const docs = await db.select().from(documents).where(eq(documents.caseId, c.id))
        return {
          ...c,
          documentCount: docs.length
        }
      })
    )
    
    res.json(result)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to fetch cases' })
  }
})

// Получение дела
app.get('/api/cases/:id', async (req, res) => {
  try {
    const caseId = req.params.id
    const caseData = await db.select().from(cases).where(eq(cases.id, caseId))
    
    if (!caseData.length) {
      return res.status(404).json({ error: 'Case not found' })
    }
    
    const docs = await db.select().from(documents).where(eq(documents.caseId, caseId))
    
    res.json({
      ...caseData[0],
      documents: docs
    })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to fetch case' })
  }
})

// Загрузка документов к делу
app.post('/api/cases/:id/documents', upload.array('files'), async (req, res) => {
  try {
    const caseId = req.params.id
    const files = req.files as Express.Multer.File[]
    
    if (!files?.length) {
      return res.status(400).json({ error: 'No files' })
    }
    
    for (const file of files) {
      const docId = uuidv4()
      await db.insert(documents).values({
        id: docId,
        caseId,
        name: file.originalname,
        type: file.mimetype,
        size: file.size,
        path: file.path
      })
    }
    
    res.json({ success: true })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to upload' })
  }
})

// AI-анализ дела
app.post('/api/cases/:id/analyze', async (req, res) => {
  try {
    const caseId = req.params.id
    
    // Получаем данные дела
    const caseData = await db.select().from(cases).where(eq(cases.id, caseId))
    const docs = await db.select().from(documents).where(eq(documents.caseId, caseId))
    
    if (!caseData.length) {
      return res.status(404).json({ error: 'Case not found' })
    }
    
    const c = caseData[0]
    
    // Формируем промпт для OpenAI
    const prompt = `
Проанализируй юридическую ситуацию:

Название: ${c.title}
Описание: ${c.description || 'Не указано'}
Документов: ${docs.length}

Дай краткий анализ (3-5 пунктов):
1. Что нужно сделать в первую очередь
2. Какие документы потребуются
3. Возможные риски
4. Рекомендации по стратегии

Формат: кратко, по делу, без воды.
`

    const completion = await openai.chat.completions.create({
      model: 'openai/gpt-4o',
      messages: [
        { role: 'system', content: 'Ты юридический консультант. Даёшь конкретные рекомендации.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 1000
    })
    
    const analysis = completion.choices[0].message.content
    
    // Сохраняем анализ
    await db.update(cases)
      .set({ analysis, status: 'active' })
      .where(eq(cases.id, caseId))
    
    res.json({ analysis })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to analyze' })
  }
})

// Скачивание документа
app.get('/api/documents/:id', async (req, res) => {
  try {
    const docId = req.params.id
    const docs = await db.select().from(documents).where(eq(documents.id, docId))
    
    if (!docs.length) {
      return res.status(404).json({ error: 'Document not found' })
    }
    
    const doc = docs[0]
    res.download(doc.path, doc.name)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to download' })
  }
})

const PORT = process.env.PORT || 3002
app.listen(PORT, () => {
  console.log(`Legal MRL API running on port ${PORT}`)
})
