import { mysqlTable, varchar, text, timestamp, json, int } from 'drizzle-orm/mysql-core'

export const cases = mysqlTable('cases', {
  id: varchar('id', { length: 36 }).primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  status: varchar('status', { length: 50 }).notNull().default('pending'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  analysis: text('analysis'),
  userId: varchar('user_id', { length: 36 })
})

export const documents = mysqlTable('documents', {
  id: varchar('id', { length: 36 }).primaryKey(),
  caseId: varchar('case_id', { length: 36 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  type: varchar('type', { length: 100 }).notNull(),
  size: int('size').notNull(),
  path: varchar('path', { length: 500 }).notNull(),
  uploadedAt: timestamp('uploaded_at').defaultNow().notNull()
})
