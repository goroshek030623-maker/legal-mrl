import { Link, useLocation } from 'react-router-dom'

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation()
  
  const isActive = (path: string) => location.pathname === path

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="text-xl font-bold text-blue-900">
                Legal MRL
              </Link>
            </div>
            <nav className="flex items-center space-x-4">
              <Link
                to="/"
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  isActive('/') ? 'bg-blue-100 text-blue-900' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Главная
              </Link>
              <Link
                to="/cases"
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  isActive('/cases') ? 'bg-blue-100 text-blue-900' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Мои дела
              </Link>
              <Link
                to="/cases/new"
                className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700"
              >
                Новое дело
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {children}
      </main>

      <footer className="bg-white border-t mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-4 text-center text-sm text-gray-500">
          Legal MRL — Юридический помощник. Не заменяет консультацию адвоката.
        </div>
      </footer>
    </div>
  )
}
