import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'

interface Document {
  id: string
  name: string
  type: string
  uploadedAt: string
}

interface Case {
  id: string
  title: string
  description: string
  status: string
  createdAt: string
  documents: Document[]
  analysis?: string
}

export default function CaseDetailPage() {
  const { id } = useParams<{ id: string }>()
  const [newFiles, setNewFiles] = useState<File[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const { data: caseData, refetch } = useQuery({
    queryKey: ['case', id],
    queryFn: async () => {
      const res = await fetch(`/api/cases/${id}`)
      return res.json() as Promise<Case>
    }
  })

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setNewFiles(Array.from(e.target.files))
    }
  }

  const handleUpload = async () => {
    if (!newFiles.length) return
    setIsUploading(true)

    try {
      const formData = new FormData()
      newFiles.forEach((file) => {
        formData.append('files', file)
      })

      const res = await fetch(`/api/cases/${id}/documents`, {
        method: 'POST',
        body: formData
      })

      if (!res.ok) throw new Error('Failed to upload')
      setNewFiles([])
      refetch()
    } catch (err) {
      alert('Ошибка загрузки: ' + (err as Error).message)
    } finally {
      setIsUploading(false)
    }
  }

  const handleAnalyze = async () => {
    setIsAnalyzing(true)
    try {
      const res = await fetch(`/api/cases/${id}/analyze`, {
        method: 'POST'
      })
      if (!res.ok) throw new Error('Failed to analyze')
      refetch()
    } catch (err) {
      alert('Ошибка анализа: ' + (err as Error).message)
    } finally {
      setIsAnalyzing(false)
    }
  }

  if (!caseData) return <div className="text-center py-8">Загрузка...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <Link to="/cases" className="hover:underline">Мои дела</Link>
        <span>/</span>
        <span>{caseData.title}</span>
      </div>

      <div className="bg-white p-6 rounded-lg border">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className="text-2xl font-bold">{caseData.title}</h1>
            <p className="text-sm text-gray-500 mt-1">
              Создано: {new Date(caseData.createdAt).toLocaleDateString('ru-RU')}
            </p>
          </div>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            caseData.status === 'active' ? 'bg-green-100 text-green-800' :
            caseData.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
            'bg-gray-100 text-gray-800'
          }`}>
            {caseData.status === 'active' ? 'Активно' :
             caseData.status === 'pending' ? 'На рассмотрении' :
             'Завершено'}
          </span>
        </div>

        {caseData.description && (
          <p className="text-gray-700 mb-4">{caseData.description}</p>
        )}

        <div className="flex gap-2">
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50"
          >
            {isAnalyzing ? 'Анализируем...' : '🔍 AI-анализ'}
          </button>
        </div>
      </div>

      {caseData.analysis && (
        <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
          <h2 className="font-semibold text-blue-900 mb-2">Результат анализа</h2>
          <div className="text-blue-800 whitespace-pre-wrap">{caseData.analysis}</div>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg border">
        <h2 className="text-lg font-semibold mb-4">Документы</h2>

        <div className="mb-4">
          <input
            type="file"
            multiple
            onChange={handleFileChange}
            className="w-full px-3 py-2 border rounded-lg mb-2"
            accept=".pdf,.doc,.docx,image/*"
          />
          {newFiles.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">
                Выбрано: {newFiles.length} файл(ов)
              </span>
              <button
                onClick={handleUpload}
                disabled={isUploading}
                className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 disabled:opacity-50"
              >
                {isUploading ? 'Загрузка...' : 'Загрузить'}
              </button>
            </div>
          )}
        </div>

        {caseData.documents?.length ? (
          <div className="space-y-2">
            {caseData.documents.map((doc) => (
              <div
                key={doc.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">
                    {doc.type.startsWith('image/') ? '📷' :
                     doc.type.includes('pdf') ? '📄' : '📎'}
                  </span>
                  <div>
                    <p className="font-medium">{doc.name}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(doc.uploadedAt).toLocaleDateString('ru-RU')}
                    </p>
                  </div>
                </div>
                <a
                  href={`/api/documents/${doc.id}`}
                  download
                  className="text-blue-600 hover:underline text-sm"
                >
                  Скачать
                </a>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-4">
            Пока нет документов. Загрузите материалы дела.
          </p>
        )}
      </div>
    </div>
  )
}
