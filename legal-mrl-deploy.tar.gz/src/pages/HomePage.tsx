import { Link } from 'react-router-dom'

export default function HomePage() {
  return (
    <div className="space-y-8">
      <div className="text-center py-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Юридический помощник
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Загрузите материалы дела, получите AI-анализ и рекомендации по составлению документов
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link
            to="/cases/new"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700"
          >
            Создать дело
          </Link>
          <Link
            to="/cases"
            className="bg-white text-blue-600 border border-blue-600 px-6 py-3 rounded-lg font-medium hover:bg-blue-50"
          >
            Мои дела
          </Link>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="text-2xl mb-2">📁</div>
          <h3 className="font-semibold mb-2">Загрузка материалов</h3>
          <p className="text-gray-600 text-sm">PDF, DOC, фото — всё что связано с делом</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="text-2xl mb-2">🤖</div>
          <h3 className="font-semibold mb-2">AI-анализ</h3>
          <p className="text-gray-600 text-sm">Изучаем ситуацию и предлагаем стратегию</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="text-2xl mb-2">📄</div>
          <h3 className="font-semibold mb-2">Готовые документы</h3>
          <p className="text-gray-600 text-sm">Иски, отзывы, ходатайства — по шаблонам</p>
        </div>
      </div>
    </div>
  )
}
