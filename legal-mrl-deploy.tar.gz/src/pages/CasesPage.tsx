import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'

interface Case {
  id: string
  title: string
  status: string
  createdAt: string
  documentCount: number
}

export default function CasesPage() {
  const { data: cases, isLoading } = useQuery({
    queryKey: ['cases'],
    queryFn: async () => {
      const res = await fetch('/api/cases')
      return res.json() as Promise<Case[]>
    }
  })

  if (isLoading) return <div className="text-center py-8">Загрузка...</div>

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Мои дела</h1>
        <Link
          to="/cases/new"
          className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700"
        >
          Новое дело
        </Link>
      </div>

      {!cases?.length ? (
        <div className="text-center py-12 bg-white rounded-lg border">
          <p className="text-gray-500 mb-4">У вас пока нет дел</p>
          <Link
            to="/cases/new"
            className="text-blue-600 font-medium hover:underline"
          >
            Создать первое дело
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {cases.map((c) => (
            <Link
              key={c.id}
              to={`/cases/${c.id}`}
              className="block bg-white p-6 rounded-lg border hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-lg">{c.title}</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Создано: {new Date(c.createdAt).toLocaleDateString('ru-RU')}
                  </p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  c.status === 'active' ? 'bg-green-100 text-green-800' :
                  c.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {c.status === 'active' ? 'Активно' :
                   c.status === 'pending' ? 'На рассмотрении' :
                   'Завершено'}
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Документов: {c.documentCount}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
